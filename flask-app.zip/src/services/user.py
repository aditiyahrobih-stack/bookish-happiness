# src/services/user.py

from bson import ObjectId
from src.extensions import mongo
from src.models.user import User


def get_all_users():
    users = mongo.db.users.find()
    return [User.from_mongo(user) for user in users]


def get_user_by_id(user_id):
    user = mongo.db.users.find_one({"_id": ObjectId(user_id)})
    return User.from_mongo(user)


def create_user(user_data):
    """user_data: dict with 'username' and 'email' keys"""
    result = mongo.db.users.insert_one(User.to_mongo(user_data))
    return str(result.inserted_id)


def update_user(user_id, user_data):
    result = mongo.db.users.update_one(
        {"_id": ObjectId(user_id)},
        {"$set": User.to_mongo(user_data)}
    )
    return result.modified_count > 0


def delete_user(user_id):
    result = mongo.db.users.delete_one({"_id": ObjectId(user_id)})
    return result.deleted_count > 0
